﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica2
{
    class tabsim
    {
        public string simbolo;
        public string direccion;

        public tabsim()
        {
        }
    }
}
