﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica2
{
    class tipoError
    {
        string lineaError;
        string mensaje;
        string tipo; 

        public tipoError()
        {

        }
    }
}
