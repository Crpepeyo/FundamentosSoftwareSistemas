﻿namespace Practica2
{
    partial class sicxeParser
    {
    }
}
