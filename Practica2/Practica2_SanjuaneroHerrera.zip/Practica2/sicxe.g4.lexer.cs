﻿namespace Practica2
{
    partial class sicxeLexer
    {
    }
}
