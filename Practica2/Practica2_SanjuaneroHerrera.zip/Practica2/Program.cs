﻿using Antlr4.Runtime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica2
{
    class Program
    {
        static void Main(string[] args) 
        {
            while (true)
            {
                Console.WriteLine("Ingresa el nombre del archivo sin su extension o ingresa # para salir\n"); //linea en consola
                string name = ""; //variable para almacenar la cadena de entrada que es el nombre del archivo
                string line = "";
                name = Console.ReadLine();
                if (String.Compare(name, "#") == 1) //si no detecta un # continua con el programa
                {
                    //abrir archivo 
                    line = File.ReadAllText(name+".xe"); // se completa el nombre del archivo con la extension .xe
                    line = line.Replace("\r", String.Empty); //quitar \r del programa 
                    sicxeLexer lex = new sicxeLexer(new AntlrInputStream(line + Environment.NewLine)); //lexer
                    lex.RemoveErrorListeners(); //quitar listeners para poder usar el metodo de errores propio
                    lex.AddErrorListener(ErroresUno.INSTANCE);//agregar metodo de manejo de errores
                    CommonTokenStream tokens = new CommonTokenStream(lex); //crear tokens segun el lexer
                    sicxeParser parser = new sicxeParser(tokens); //parser con tokens creados
                    parser.RemoveErrorListeners();//quitar listeners para poder usar el metodo de errores propio
                    parser.AddErrorListener(ErroresToken.INSTANCE); //agregar metodo de manejo de errores
                    try
                    {
                        parser.programa(); //llamada a parser en programa
                    }
                    catch (RecognitionException e)
                    {
                        Console.WriteLine(e);
                    }
                }
                else { Environment.Exit(1); }
                Console.ReadLine();
            }

        }
    }
 }

